
cc.Class({
    extends: cc.Component,

    properties: {
        bg:     cc.Node,
        time:   cc.Label,
        loai:   cc.Label,
        so:     cc.Label,
        diem:   cc.Label,
        cuoc:   cc.Label,
        win:    cc.Label,
        status: cc.Label,
    },
});
